# -*- coding: utf-8 -*-
from __future__ import with_statement

def paas():
    # this part is compatible with goagent 1.1.0 by phus.lu@gmail.com and others
    print 'Initializing PAAS for proxy based on cloud service.'
    set_hosts, Forward = config.import_from('util')
    HeaderDict, Proxy, URLInfo = config.import_from(utils)
    import re, zlib, socket, struct, time, random
    from binascii import a2b_hex, b2a_hex
    from base64 import b64encode
    try:
        import ssl
    except ImportError:
        ssl = None

    class HTTPError(Exception):
        def __init__(self, code, msg):
            self.code = code
            self.msg = msg

        def __str__(self):
            return 'HTTP Error %s: %s' % (self.code, self.msg)

    _range_re = re.compile(r'(\d+)?-(\d+)?')
    _crange_re = re.compile(r'bytes\s+(\d+)-(\d+)/(\d+)')
    def _process_range(headers, max_range):
        range = headers.get('Range', '')
        m = _range_re.search(range)
        if m:
            m = m.groups()
            if m[0]:
                max_range -= 1
                if m[1]:
                    m = 2, int(m[0]), int(m[1])
                    if m[2] - m[1] > max_range:
                        range = 'bytes=%d-%d' % (m[1], m[1] + max_range)
                else:
                    m = 0, int(m[0])
                    range = 'bytes=%d-%d' % (m[1], m[1] + max_range)
            else:
                if m[1]:
                    m = 1, int(m[1])
                    if m[1] > max_range:
                        range = 'bytes=-1024'
                else:
                    m = None,
                    range = 'bytes=0-%d' % (max_range - 1)
        else:
            m = None,
            range = 'bytes=0-%d' % (max_range - 1)
        return m, range

    _setcookie_re = re.compile(r', ([^ =]+(?:=|$))')
    def _fix_setcookie(headers):
        hdr = headers.get('Set-Cookie')
        if hdr:
            headers['Set-Cookie'] = _setcookie_re.sub(r'\r\nSet-Cookie: \1', hdr)
        return headers

    def GAE(**kw):
        self = _GAEHandler
        v = kw.get('appids', '')
        self.appids = v = v.split() if isinstance(v, str) else list(v)
        if not v: raise ValueError('no appids specified')
        scheme = kw.get('scheme', 'http').lower()
        if scheme not in ('http', 'https'):
            raise ValueError('invalid scheme: '+scheme)
        self.url = URLInfo('%s://%s.appspot.com%s?' % (
            scheme, self.appids[0], kw.get('path', '/fetch.py')))
        self.password = kw.get('password', '')
        v = kw.get('proxy', 'default')
        self.proxy = utils.global_proxy if v == 'default' else Proxy(v)
        v = kw.get('hosts', '')
        v = v.split() if isinstance(v, str) else list(v)
        if not v:
            v = ('eJxdztsNgDAMQ9GNIvIoSXZjeApSqc3nUVT3ZojakFTR47wSNEhB8qXhorXg+kM'
                 'jckGtQM9efDKf91Km4W+N4M1CldNIYMu+qSVoTm7MsG5E4KPd8apInNUUMo4bet'
                 'RQjg==').decode('base64').decode('zlib').split('|')
        set_hosts('.appspot.com', v, False)
        if self.proxy.value:
            self.hosts = v
            self.proxy = self.proxy.new_hosts((v[0], self.url.port))
        self.headers = HeaderDict(kw.get('headers',
            'Content-Type: application/octet-stream'))
        self.bufsize = kw.get('bufsize', 8192)
        self.maxsize = kw.get('maxsize', 1048576)
        self.waitsize = kw.get('waitsize', 524288)
        assert self.bufsize <= self.waitsize <= self.maxsize
        self.local_times = kw.get('local_times', 3)
        self.server_times = kw.get('server_times')
        print '  Init GAE with appids: %s' % '|'.join(self.appids)
        return self

    class GAEHandler(object):
        skip_headers = frozenset(['Proxy-Connection', 'Content-Length', 'Host',
            'Vary', 'Via', 'X-Forwarded-For', 'X-ProxyUser-IP'])

        def build_params(self, req, force_range):
            method = req.command; headers = req.headers
            if method == 'GET':
                req.rangeinfo, range = _process_range(headers, self.maxsize)
                if force_range or req.rangeinfo[0] == 0:
                    headers['Range'] = range
            else:
                req.rangeinfo, range = (None,), ''
            skip_headers = self.skip_headers
            headers.data = dict(kv for kv in headers.iteritems()
                if kv[0] not in skip_headers)
            params = {'url':req.url, 'method':method,
                'headers':headers, 'payload':req.read_body()}
            # params['range'] = range
            if self.password:
                params['password'] = self.password
            if self.server_times:
                params['fetchmax'] = self.server_times
            return params

        def fetch(self, params):
            params = zlib.compress('&'.join(['%s=%s' % (k, b2a_hex(str(v)))
                for k,v in params.iteritems()]), 9)
            errors = []
            url = self.url
            opener = self.proxy.get_opener(url.scheme)
            for i in xrange(self.local_times):
                flag = 0
                try:
                    resp = opener.open(url, params, 'POST', self.headers, 0)
                    if resp.status != 200:
                        resp.close()
                        raise HTTPError(resp.status, resp.reason)
                except Exception, e:
                    opener.close()
                    if isinstance(e, HTTPError):
                        errors.append(str(e))
                        if e.code == 503:
                            self.appids.append(self.appids.pop(0)); flag |= 1
                            url.hostname = '%s.appspot.com' % self.appids[0]
                            print 'GAE: switch appid to %s' % self.appids[0]
                    else:
                        if (url.scheme != 'https' and isinstance(e, socket.error)
                            and e.args[0] in (10054, 10060, 104)):
                            url.scheme = 'https'; url.port = 443; flag |= 3
                            print 'GAE: switch scheme to https'
                        if self.proxy.value:
                            errors.append('Connect other proxy failed: %s' % e)
                            self.hosts.append(self.hosts.pop(0)); flag |= 2
                            print 'GAE: switch host to %s' % self.hosts[0]
                        else:
                            errors.append('Connect fetchserver failed: %s' % e)
                    if flag & 1:
                        url.rebuild()
                    if flag & 2:
                        if self.proxy.value:
                            self.proxy = self.proxy.new_hosts(
                                (self.hosts[0], url.port))
                        opener = self.proxy.get_opener(url.scheme)
                else:
                    try:
                        flag = resp.read(1)
                        if flag == '0':
                            code, hlen, clen = struct.unpack('>3I', resp.read(12))
                            headers = HeaderDict([(k, a2b_hex(v))
                                for k,_,v in (x.partition('=')
                                for x in resp.read(hlen).split('&'))])
                        elif flag == '1':
                            rawdata = zlib.decompress(resp.read()); resp.close()
                            code, hlen, clen = struct.unpack('>3I', rawdata[:12])
                            headers = HeaderDict([(k, a2b_hex(v))
                                for k,_,v in (x.partition('=')
                                for x in rawdata[12:12+hlen].split('&'))])
                            resp = rawdata[12+hlen:12+hlen+clen]
                        else:
                            raise ValueError('Data format not match(%s)' % url)
                        headers.setdefault('Content-Length', str(clen))
                        return 0, (code, headers, resp)
                    except Exception, e:
                        errors.append(str(e))
                time.sleep(i + 1)
            return -1, errors

        def need_range_fetch(self, req, headers, resp):
            m = _crange_re.search(headers.get('Content-Range', ''))
            if not m: return None
            m = map(int, m.groups())#bytes %d-%d/%d
            info = req.rangeinfo
            t = info[0]
            if t is None:
                start = 0; end = m[2] - 1; code = 200
                del headers['Content-Range']
            else:
                if t == 0: #bytes=%d-
                    start = info[1]; end = m[2] - 1
                elif t == 1: #bytes=-%d
                    start = m[2] - info[1]; end = m[2] - 1
                else: #bytes=%d-%d
                    start = info[1]; end = info[2]
                code = 206
                headers['Content-Range'] = 'bytes %d-%d/%d' % (start, end, m[2])
            headers['Content-Length'] = str(end - start + 1)
            req.start_response(code, headers)
            if start == m[0]: #Valid
                self.write_content(req, resp,
                    headers.get('Content-Type', '').startswith('video/'))
                start = m[1] + 1
            return start, end

        def write_content(self, req, resp, video=False):
            sendall = req.socket.sendall
            if isinstance(resp, str):
                sendall(resp)
            else:
                bufsize = self.bufsize
                data = resp.read(self.waitsize if video else bufsize)
                while data:
                    sendall(data)
                    data = resp.read(bufsize)
                resp.close()

        def range_fetch(self, req, params, (start, end)):
            # del params['range'] # disable server auto-range-fetch
            failed = 0; step = self.maxsize - 1; iheaders = params['headers']
            print ('>>>>>>>>>> Range Fetch started%s: bytes=%d-%d'
                % (req.proxy_host, start, end))
            while start <= end:
                if failed > 16: break
                iheaders['Range'] = 'bytes=%d-%d' % (start, min(start+step, end))
                flag, data = self.fetch(params)
                if flag != -1:
                    code, headers, resp = data
                    m = _crange_re.search(headers.get('Content-Range', ''))
                if flag == -1 or code >= 400:
                    failed += 1
                    seconds = random.randint(2*failed, 2*(failed+1))
                    time.sleep(seconds)
                elif 'Location' in headers:
                    failed += 1
                    params['url'] = headers['Location']
                elif not m:
                    failed += 1
                else:
                    print '>>>>>>>>>> %s' % headers['Content-Range']
                    failed = 0
                    self.write_content(req, resp)
                    start = int(m.group(2)) + 1
            print '>>>>>>>>>> Range Fetch ended%s' % (req.proxy_host,)

        def RangeFetch(self, req):
            return self(req, True)

        def __call__(self, req, force_range=False):
            params = self.build_params(req, force_range)
            flag, data = self.fetch(params)
            if flag == -1:
                return req.send_error(502, str(data))
            code, headers, resp = data
            if code == 206 and req.command == 'GET':
                data = self.need_range_fetch(req, headers, resp)
                if data:
                    return self.range_fetch(req, params, data)
            req.start_response(code, headers)
            self.write_content(req, resp)

    _GAEHandler = GAEHandler()

    def PAAS(**kw):
        self = PAASHandler()
        self.url = url = URLInfo(kw['url'])
        self.password = kw.get('password', '')
        v = kw.get('proxy', 'default')
        self.proxy = utils.global_proxy if v == 'default' else Proxy(v)
        v = kw.get('hosts', '')
        v = v.split() if isinstance(v, str) else list(v)
        if not v:
            v = [url.hostname]
        set_hosts(url.hostname, v, False)
        if self.proxy.value:
            self.hosts = v
            self.proxy = self.proxy.new_hosts((v[0], url.port))
        self.headers = HeaderDict(kw.get('headers',
            'Content-Type: application/octet-stream'))
        print '  Init PAAS with url: %s' % url
        return self

    class PAASHandler(object):
        def __call__(self, req):
            params = {'method':req.command, 'url':req.url, 'headers':req.headers}
            if self.password:
                params['password'] = self.password
            params = '&'.join(['%s=%s' % (k, b2a_hex(str(v)))
                for k,v in params.iteritems()])
            self.headers['Cookie'] = b64encode(zlib.compress(params, 9))

            url = self.url
            try:
                resp = self.proxy.get_opener(url.scheme).open(
                    url, req.read_body(), 'POST', self.headers, 0)
            except Exception, e:
                if self.proxy.value and len(self.hosts) > 1:
                    self.hosts.append(self.hosts.pop(0))
                    print 'PAAS: switch host to %s' % self.hosts[0]
                    self.proxy = self.proxy.new_hosts((self.hosts[0], url.port))
                    return req.send_error(502, 'Connect other proxy failed: %s' % e)
                else:
                    return req.send_error(502, 'Connect fetchserver failed: %s' % e)
            req.start_response(resp.status, _fix_setcookie(resp.msg), resp.reason)
            sendall = req.socket.sendall
            data = resp.read(8192)
            while data:
                sendall(data)
                data = resp.read(8192)
            resp.close()

    def SOCKS5(**kw):
        self = SOCKS5Handler()
        url = URLInfo(kw['url'])
        self.scheme = url.scheme
        self.host = url.host
        self.path = url.path
        v = kw.get('password')
        self.auth = v if v is None else ('',v)
        print self.auth
        v = kw.get('proxy', 'default')
        self.proxy = utils.global_proxy if v == 'default' else Proxy(v)
        if self.scheme == 'https' and self.proxy.https_mode:
            self.proxy = self.proxy.https_mode
        v = kw.get('hosts', '')
        v = v.split() if isinstance(v, str) else list(v)
        if not v:
            v = [url.hostname]
        set_hosts(url.hostname, v, False)
        self.value = [v[0], url.port]
        print '  Init SOCKS5 with url: %s' % url
        return Forward(self)

    class SOCKS5Handler(Proxy):
        __new__ = object.__new__

        def connect(self, addr, timeout, cmd=1):
            try:
                sock = self.proxy.connect(self.value, timeout, 1)
            except Exception:
                if self.proxy.value and len(self.hosts) > 1:
                    self.hosts.append(self.hosts.pop(0))
                    print 'SOCKS5: switch host to %s' % self.hosts[0]
                    self.value[0] = self.hosts[0]
                raise
            if self.scheme == 'https':
                try:
                    sock = ssl.wrap_socket(sock)
                except Exception, e:
                    raise socket.error(e)
            sock.sendall('PUT %s HTTP/1.1\r\nHost: %s\r\n'
                'Connection: Keep-Alive\r\n\r\n' % (self.path, self.host))
            connect = self.handlers['socks5']
            addr = connect(sock, sock.makefile('rb', 0), self.auth, 0, addr, cmd)
            return self._proxysocket(sock, addr)

    globals().update(GAE=GAE, PAAS=PAAS, SOCKS5=SOCKS5)
