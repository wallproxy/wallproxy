# -*- coding: utf-8 -*-
from __future__ import with_statement

import ConfigParser, os, re, urlparse, os.path as ospath

class Common(object):
    v = '''def %s(self, section, option, default):
    try:
        return self.CONFIG.%s(section, option)
    except:
        return default
'''
    for k in ('get', 'getint', 'getboolean'):
        exec(v % (k, k))
    del k, v

    def __init__(self, INPUT):
        ConfigParser.RawConfigParser.OPTCRE = re.compile(r'(?P<option>[^=\s][^=]*)\s*(?P<vi>[=])\s*(?P<value>.*)$')
        CONFIG = self.CONFIG = ConfigParser.ConfigParser()
        CONFIG.read(INPUT)

        self.LISTEN_IP          = self.get('listen', 'ip', '127.0.0.1')
        self.LISTEN_PORT        = self.getint('listen', 'port', 8086)
        self.USERNAME           = self.get('listen', 'username', None)
        self.WEB_USERNAME       = self.get('listen', 'web_username', 'admin')
        self.WEB_PASSWORD       = self.get('listen', 'web_password', 'admin')
        if self.USERNAME is not None:
            self.PASSWORD       = CONFIG.get('listen', 'password')
            self.BASIC_AUTH     = self.getboolean('listen', 'basic_auth', False)
            self.DISABLE_SOCKS4 = self.getboolean('listen', 'disable_socks4', False)
            self.DISABLE_SOCKS5 = self.getboolean('listen', 'disable_socks5', False)
        self.CERT_WILDCARD      = self.getboolean('listen', 'cert_wildcard', True)
        self.TASKS_DELAY        = self.getint('listen', 'tasks_delay', 0)

        self.GAE_ENABLE         = self.getint('gae', 'enable', True)
        self.GAE_LISTEN         = self.GAE_ENABLE and self.get('gae', 'listen', '8087')
        if self.LISTEN_PORT == 8087 and self.GAE_LISTEN == '8087':
            self.LISTEN_PORT = 8086
        self.GAE_APPIDS         = self.get('gae', 'appid', '').replace('.appspot.com', '').split('|')
        self.GAE_PASSWORD       = self.CONFIG.get('gae', 'password').strip()
        self.GAE_PATH           = self.CONFIG.get('gae', 'path')
        self.GAE_PROFILE        = self.CONFIG.get('gae', 'profile')
        self.GAE_MAXTHREADS     = self.getint('gae', 'max_threads', 0)
        self.GAE_PROXY          = self.get('gae', 'proxy', 'default')
        self.GAE_HANDLER        = self.GAE_LISTEN and self.getboolean('gae', 'find_handler', True)

        self.PAAS_ENABLE        = self.CONFIG.getint('paas', 'enable')
        self.PAAS_LISTEN        = self.get('paas', 'listen', '')
        self.PAAS_PASSWORD      = self.CONFIG.get('paas', 'password') if self.CONFIG.has_option('paas', 'password') else ''
        self.PAAS_FETCHSERVER   = self.CONFIG.get('paas', 'fetchserver').split('|')
        self.PAAS_PROXY         = self.get('paas', 'proxy', 'default')

        if self.CONFIG.has_section('socks5'):
            self.SOCKS5_ENABLE      = self.CONFIG.getint('socks5', 'enable')
            self.SOCKS5_LISTEN      = self.get('socks5', 'listen', '')
            self.SOCKS5_PASSWORD    = self.CONFIG.get('socks5', 'password') if self.CONFIG.has_option('socks5', 'password') else ''
            self.SOCKS5_FETCHSERVER = self.CONFIG.get('socks5', 'fetchserver')
            self.SOCKS5_PROXY          = self.get('socks5', 'proxy', 'default')
        else:
            self.SOCKS5_ENABLE  = 0
        self.TARGET_PAAS        = self.GAE_ENABLE and 'GAE' or self.PAAS_ENABLE and 'PAAS' or self.SOCKS5_ENABLE and 'SOCKS5'

        self.GLOBAL_PROXY       = self.getint('proxy', 'enable', 0) or None
        PAC_DEFAULT = PY_DEFAULT = 'DIRECT'
        if self.GLOBAL_PROXY:
            PROXY_HOST          = self.CONFIG.get('proxy', 'host')
            PROXY_PORT          = self.CONFIG.getint('proxy', 'port')
            PROXY_USERNAME      = self.get('proxy', 'username', '')
            PROXY_PASSWROD      = self.get('proxy', 'password', '')
            self.GLOBAL_PROXY   = 'http://%s:%s@%s:%s' % (PROXY_USERNAME, PROXY_PASSWROD, PROXY_HOST, PROXY_PORT)
            PAC_DEFAULT         = 'PROXY %s:%s; DIRECT' % (PROXY_HOST, PROXY_PORT)

        self.PAC_ENABLE         = self.getboolean('pac', 'enable', True)
        v = self.getint('pac', 'https_mode', 1)
        self.PAC_HTTPSMODE = 0 if v <= 0 else (2 if v >= 2 else 1)
        v = self.get('pac', 'file', '').replace('goagent', 'proxy')
        self.PAC_FILE           = v and v.split('|')
        if self.PAC_FILE:
            self.PAC_DEFAULT    = self.get('pac', 'default', '') or PAC_DEFAULT
        else:
            self.PAC_DEFAULT    = self.get('pac', 'py_default', '') or PY_DEFAULT
        self.PAC_RULELIST = v   = self.get('pac', 'rulelist', 'http://autoproxy-gfwlist.googlecode.com/svn/trunk/gfwlist.txt|userlist.ini')
        if v.startswith('!'):
            if self.PAC_FILE:
                v = self.CONFIG.items(v.lstrip('!').strip())
            else:
                v = self.CONFIG.items('py_'+v.lstrip('!').strip())
            self.PAC_RULELIST   = [(v.split('|'),k.upper()) for k,v in v if k and v]
        elif v:
            self.PAC_RULELIST = [(v.split('|'), 'PROXY *:*; DIRECT' if self.PAC_FILE else self.TARGET_PAAS)]

        self.GOOGLE_MODE        = self.get(self.GAE_PROFILE, 'mode', 'http')
        v = self.get(self.GAE_PROFILE, 'hosts', '')
        self.GOOGLE_HOSTS       = v and tuple(v.split('|')) or ()
        v = self.get(self.GAE_PROFILE, 'sites', '')
        self.GOOGLE_SITES       = v and tuple(v.split('|')) or ()
        v = self.get(self.GAE_PROFILE, 'forcehttps', '')
        self.GOOGLE_FORCEHTTPS  = v and tuple(v.split('|')) or ()
        v = self.get(self.GAE_PROFILE, 'withgae', '')
        GOOGLE_WITHGAE          = v and tuple(v.split('|')) or ()

        self.FETCHMAX_LOCAL     = self.getint('fetchmax', 'local', 3)
        self.FETCHMAX_SERVER    = self.getint('fetchmax', 'server', 0)

        self.AUTORANGE_ENABLE   = self.getboolean('autorange', 'enable', False)
        v = self.get('autorange', 'hosts', '')
        self.AUTORANGE_HOSTS    = v and tuple(v.split('|')) or ()
        self.AUTORANGE_MAXSIZE  = self.getint('autorange', 'maxsize', 1000000)
        self.AUTORANGE_WAITSIZE = self.getint('autorange', 'waitsize', 500000)
        self.AUTORANGE_BUFSIZE  = self.getint('autorange', 'bufsize', 8192)

        assert self.AUTORANGE_BUFSIZE <= self.AUTORANGE_WAITSIZE <= self.AUTORANGE_MAXSIZE

        v = self.get('hosts', 'rules', '')
        if v.startswith('!'):
            v = v.lstrip('!').strip(); self.HOSTS_RULES = v and v.split('|')
        else:
            self.HOSTS_RULES = v.replace(r'\n', '\n')
        if self.CONFIG.has_option('hosts', 'rules'):
            self.CONFIG.remove_option('hosts', 'rules')
        self.HOSTS              = dict((k, tuple(v.split('|')) if v else tuple()) for k, v in self.CONFIG.items('hosts'))

        self.USERAGENT_ENABLE   = self.getint('useragent', 'enable', 0)
        self.USERAGENT_STRING   = self.get('useragent', 'string', '')

        self.AUTORANGE_HOSTS    = self.GAE_ENABLE and self.AUTORANGE_ENABLE and self.AUTORANGE_HOSTS
        self.PAC_ENABLE         = self.TARGET_PAAS and self.PAC_RULELIST and self.PAC_ENABLE
        self.HOSTS_RULES        = self.TARGET_PAAS and self.HOSTS_RULES
        self.NEED_PAC           = self.AUTORANGE_HOSTS or self.PAC_ENABLE or self.HOSTS_RULES
        self.HOSTS_RULES2 = self.GOOGLE_WITHGAE = False
        if self.TARGET_PAAS and self.GOOGLE_SITES and not self.GLOBAL_PROXY:
            self.GOOGLE_WITHGAE = ' \n '.join([(i if '/' in i else '||%s'%i.lstrip('.')) for i in GOOGLE_WITHGAE])
            if isinstance(self.HOSTS_RULES, basestring):
                v = ' \n '.join(['||%s'%i.lstrip('.') for i in self.GOOGLE_SITES])
                self.HOSTS_RULES = ' \n '.join((self.HOSTS_RULES, v))
            else:
                self.HOSTS_RULES2 = True


def tob(s, enc='utf-8'):
    return s.encode(enc) if isinstance(s, unicode) else bytes(s)
def touni(s, enc='utf-8', err='strict'):
    return s.decode(enc, err) if isinstance(s, str) else unicode(s)

class SimpleTemplate(object):
    """SimpleTemplate from bottle"""
    blocks = ('if', 'elif', 'else', 'try', 'except', 'finally', 'for', 'while',
              'with', 'def', 'class')
    dedent_blocks = ('elif', 'else', 'except', 'finally')
    re_pytokens = re.compile(r'''
            (''(?!')|""(?!")|'{6}|"{6}    # Empty strings (all 4 types)
             |'(?:[^\\']|\\.)+?'          # Single quotes (')
             |"(?:[^\\"]|\\.)+?"          # Double quotes (")
             |'{3}(?:[^\\]|\\.|\n)+?'{3}  # Triple-quoted strings (')
             |"{3}(?:[^\\]|\\.|\n)+?"{3}  # Triple-quoted strings (")
             |\#.*                        # Comments
            )''', re.VERBOSE)

    def __init__(self, source, encoding='utf-8'):
        self.source = source
        self.encoding = encoding
        self._str = lambda x: touni(repr(x), encoding)
        self._escape = lambda x: touni(x, encoding)

    @classmethod
    def split_comment(cls, code):
        """ Removes comments (#...) from python code. """
        if '#' not in code: return code
        #: Remove comments only (leave quoted strings as they are)
        subf = lambda m: '' if m.group(0)[0]=='#' else m.group(0)
        return re.sub(cls.re_pytokens, subf, code)

    @property
    def co(self):
        # print self.code
        return compile(self.code, '<string>', 'exec')

    @property
    def code(self):
        stack = [] # Current Code indentation
        lineno = 0 # Current line of code
        ptrbuffer = [] # Buffer for printable strings and token tuple instances
        codebuffer = [] # Buffer for generated python code
        multiline = dedent = oneline = False
        template = self.source

        def yield_tokens(line):
            for i, part in enumerate(re.split(r'\{\{(.*?)\}\}', line)):
                if i % 2:
                    if part.startswith('!'): yield 'RAW', part[1:]
                    else: yield 'CMD', part
                else: yield 'TXT', part

        def flush(): # Flush the ptrbuffer
            if not ptrbuffer: return
            cline = ''
            for line in ptrbuffer:
                for token, value in line:
                    if token == 'TXT': cline += repr(value)
                    elif token == 'RAW': cline += '_str(%s)' % value
                    elif token == 'CMD': cline += '_escape(%s)' % value
                    cline +=  ', '
                cline = cline[:-2] + '\\\n'
            cline = cline[:-2]
            if cline[:-1].endswith('\\\\\\\\\\n'):
                cline = cline[:-7] + cline[-1] # 'nobr\\\\\n' --> 'nobr'
            cline = '_printlist([' + cline + '])'
            del ptrbuffer[:] # Do this before calling code() again
            code(cline)

        def code(stmt):
            for line in stmt.splitlines():
                codebuffer.append('  ' * len(stack) + line.strip())

        for line in template.splitlines(True):
            lineno += 1
            line = touni(line, self.encoding)
            sline = line.lstrip()
            if lineno <= 2:
                m = re.match(r"%\s*#.*coding[:=]\s*([-\w.]+)", sline)
                if m: self.encoding = m.group(1)
                if m: line = line.replace('coding','coding (removed)')
            if sline and sline[0] == '%' and sline[:2] != '%%':
                line = line.split('%',1)[1].lstrip() # Full line following the %
                cline = self.split_comment(line).strip()
                cmd = re.split(r'[^a-zA-Z0-9_]', cline)[0]
                flush() # You are actually reading this? Good luck, it's a mess :)
                if cmd in self.blocks or multiline:
                    cmd = multiline or cmd
                    dedent = cmd in self.dedent_blocks # "else:"
                    if dedent and not oneline and not multiline:
                        cmd = stack.pop()
                    code(line)
                    oneline = not cline.endswith(':') # "if 1: pass"
                    multiline = cmd if cline.endswith('\\') else False
                    if not oneline and not multiline:
                        stack.append(cmd)
                elif cmd == 'end' and stack:
                    code('#end(%s) %s' % (stack.pop(), line.strip()[3:]))
                else:
                    code(line)
            else: # Line starting with text (not '%') or '%%' (escaped)
                if line.strip().startswith('%%'):
                    line = line.replace('%%', '%', 1)
                ptrbuffer.append(yield_tokens(line))
        flush()
        return '\n'.join(codebuffer) + '\n'

    def execute(self, _stdout, *args, **kwargs):
        for dictarg in args: kwargs.update(dictarg)
        env = {}
        env.update({'_stdout': _stdout, '_printlist': _stdout.extend,
               '_str': self._str, '_escape': self._escape, 'get': env.get,
               'setdefault': env.setdefault, 'defined': env.__contains__})
        env.update(kwargs)
        eval(self.co, env)
        return env

    def render(self, *args, **kwargs):
        """ Render the template using keyword arguments as local variables. """
        for dictarg in args: kwargs.update(dictarg)
        stdout = []
        self.execute(stdout, kwargs)
        return ''.join(stdout)


template = r"""# -*- coding: utf-8 -*-

# 是否使用ini作为配置文件，0不使用
ini_config = {{MTIME}}
# 监听ip
listen_ip = '{{LISTEN_IP}}'
# 监听端口
listen_port = {{LISTEN_PORT}}
# 是否使用通配符证书
cert_wildcard = {{int(CERT_WILDCARD)}}
# 更新PAC时也许还没联网，等待tasks_delay秒后才开始更新
tasks_delay = {{!TASKS_DELAY}}
# WEB界面是否对本机也要求认证
web_authlocal = 1
# 登录WEB界面的用户名
web_username = {{!WEB_USERNAME}}
# 登录WEB界面的密码
web_password = {{!WEB_PASSWORD}}
# 全局代理
global_proxy = {{!GLOBAL_PROXY}}

def config():
    Forward, set_hosts, check_auth, redirect_https = import_from('util')
    DIRECT = Forward()
%for k,v in HOSTS.iteritems():
%if k and v:
    set_hosts({{!k}}, {{!v}})
%end
%end
%if GOOGLE_FORCEHTTPS:
    forcehttps_sites = {{!GOOGLE_FORCEHTTPS}}
%end
    google_sites = {{!GOOGLE_SITES}}
    google_hosts = {{!GOOGLE_HOSTS}}
    set_hosts(google_sites, google_hosts)
%if TARGET_PAAS:

    from plugins import paas; paas = install('paas', paas)
%end #TARGET_PAAS
%if GAE_ENABLE:
    GAE = paas.GAE(appids={{!GAE_APPIDS}}\\
%if GAE_LISTEN:
, listen={{!GAE_LISTEN}}\\
%end
%if GAE_PASSWORD:
, password={{!GAE_PASSWORD}}\\
%end
%if GAE_PATH:
, path={{!GAE_PATH}}\\
%end
%if GOOGLE_MODE == 'https':
, scheme='https'\\
%end
%if GAE_PROXY != 'default':
, proxy={{!GAE_PROXY}}\\
%end
, hosts=google_hosts\\
%if AUTORANGE_MAXSIZE and AUTORANGE_MAXSIZE != 1000000:
, maxsize={{!AUTORANGE_MAXSIZE}}\\
%end
%if AUTORANGE_WAITSIZE and AUTORANGE_WAITSIZE != 500000:
, waitsize={{!AUTORANGE_WAITSIZE}}\\
%end
%if AUTORANGE_BUFSIZE and AUTORANGE_BUFSIZE != 8192:
, bufsize={{!AUTORANGE_BUFSIZE}}\\
%end
%if FETCHMAX_LOCAL and FETCHMAX_LOCAL != 3:
, local_times={{!FETCHMAX_LOCAL}}\\
%end
%if FETCHMAX_SERVER and FETCHMAX_SERVER != 3:
, server_times={{!FETCHMAX_SERVER}}\\
%end
%if GAE_MAXTHREADS:
, max_threads={{!GAE_MAXTHREADS}}\\
%end
)
%end #GAE_ENABLE
%if PAAS_ENABLE:
%for i,k in enumerate(PAAS_FETCHSERVER):
    PAAS{{i+1 if len(PAAS_FETCHSERVER) > 1 else ''}} = paas.PAAS(url={{!k}}\\
%if PAAS_LISTEN and i == 0:
, listen={{!PAAS_LISTEN}}\\
%end
%if PAAS_PASSWORD:
, password={{!PAAS_PASSWORD}}\\
%end
%if PAAS_PROXY != 'default':
, proxy={{!PAAS_PROXY}}\\
%end
)
%end
%if len(PAAS_FETCHSERVER) > 1:
    PAAS0 = ({{', '.join(['PAAS%d'%i for i in xrange(1, len(PAAS_FETCHSERVER)+1)])}})
    from random import choice
    PAAS = lambda req: choice(PAAS0)(req)
%end
%end #PAAS_ENABLE
%if SOCKS5_ENABLE:
    SOCKS5 = paas.SOCKS5(url={{!SOCKS5_FETCHSERVER}}\\
%if SOCKS5_LISTEN:
, listen={{!SOCKS5_LISTEN}}\\
%end
%if SOCKS5_PASSWORD:
, password={{!SOCKS5_PASSWORD}}\\
%end
%if SOCKS5_PROXY != 'default':
, proxy={{!SOCKS5_PROXY}}\\
%end
)
%end #SOCKS5_ENABLE
%if NEED_PAC:

    PacFile, RuleList, HostList = import_from('pac')
%end #NEED_PAC
%if AUTORANGE_HOSTS:
    _GAE = GAE; autorange_sites = HostList({{!AUTORANGE_HOSTS}})
    GAE = lambda req: _GAE(req, autorange_sites.match(req.proxy_host[0]))
%end #AUTORANGE_HOSTS
%if GAE_HANDLER:
%if USERNAME:
    @check_auth({{!USERNAME}}, {{!PASSWORD}}\\
%if DISABLE_SOCKS4:
, socks4=False\\
%end
%if DISABLE_SOCKS5 and not SOCKS5_ENABLE:
, socks5=False\\
%end
%if BASIC_AUTH:
, digest=False\\
%end
)
%end #USERNAME
    def find_gae_handler(req):
        proxy_type = req.proxy_type
        if proxy_type.endswith('http'):
            host, port = req.proxy_host
            url = req.url
%if USERAGENT_ENABLE:
            req.headers['User-Agent'] = {{!USERAGENT_STRING}}
%end
%if GOOGLE_FORCEHTTPS:
            if host in forcehttps_sites and proxy_type != 'https2http':
                return redirect_https
%end
%if GOOGLE_WITHGAE:
            if withgae_sites.match(url, host):
                return GAE
%end
%if HOSTS_RULES:
            if hosts_rules.match(url, host):
                return DIRECT
%end
%if HOSTS_RULES2:
            if host.endswith(google_sites):
                return DIRECT
%end
            return GAE
    paas.data['GAE_server'].find_handler = find_gae_handler

%end #GAE_HANDLER
%if GOOGLE_WITHGAE:
    withgae_sites = RuleList({{!GOOGLE_WITHGAE}})
%end #GOOGLE_WITHGAE
%if HOSTS_RULES:
    hosts_rules = RuleList({{!HOSTS_RULES}})
%end #HOSTS_RULES
%if TARGET_PAAS:
    DIRECT.http_failed_handler = {{TARGET_PAAS}}
%end
%if PAC_ENABLE:

    rulelist = (
%for k,v in PAC_RULELIST:
%if PAC_FILE:
        ({{!k}}, {{!v}}),
%else:
        (RuleList({{!k}}), {{v}}),
%end #PAC_FILE
%end #PAC_RULELIST
    )
%if PAC_FILE:
    PacFile(rulelist, [], {{!PAC_FILE}}, {{!PAC_DEFAULT}})
%elif PAC_HTTPSMODE == 2:
    unparse_netloc = import_from(install('utils', lambda:globals().update(vars(utils))))
%end #PAC_FILE
%end #PAC_ENABLE

%if USERNAME:
    @check_auth({{!USERNAME}}, {{!PASSWORD}}\\
%if DISABLE_SOCKS4:
, socks4=False\\
%end
%if DISABLE_SOCKS5 and not SOCKS5_ENABLE:
, socks5=False\\
%end
%if BASIC_AUTH:
, digest=False\\
%end
)
%end #USERNAME
    def find_proxy_handler(req):
        proxy_type = req.proxy_type
        host, port = req.proxy_host
        if proxy_type.endswith('http'):
            url = req.url
%if USERAGENT_ENABLE:
            req.headers['User-Agent'] = {{!USERAGENT_STRING}}
%end
%if GOOGLE_FORCEHTTPS:
            if host in forcehttps_sites and proxy_type != 'https2http':
                return redirect_https
%end
%if GOOGLE_WITHGAE:
            if withgae_sites.match(url, host):
                return {{TARGET_PAAS}}
%end
%if HOSTS_RULES:
            if hosts_rules.match(url, host):
                return DIRECT
%end
%if HOSTS_RULES2:
            if host.endswith(google_sites):
                return DIRECT
%end
%if PAC_ENABLE and not PAC_FILE:
            for rule,target in rulelist:
                if rule.match(url, host):
                    return target
            return {{PAC_DEFAULT}}
%elif TARGET_PAAS:
            return {{TARGET_PAAS}}
%else:
            return DIRECT
%end
%if not TARGET_PAAS:
        return DIRECT
%elif PAC_ENABLE and not PAC_FILE and PAC_HTTPSMODE != 1:
        elif proxy_type.endswith('https'):
%if PAC_HTTPSMODE == 2:
            url = 'https://%s/' % unparse_netloc((host, port), 443)
            for rule,target in rulelist:
                if rule.match(url, host):
                    return
%end
            return DIRECT
%elif SOCKS5_ENABLE:
        elif proxy_type == 'socks5':
            return SOCKS5
%end
    return find_proxy_handler
"""

def make_config(INPUT=None, OUTPUT=None):
    if not (INPUT and OUTPUT):
        if INPUT:
            OUTPUT = ospath.join(ospath.dirname(INPUT), 'config.py')
        elif OUTPUT:
            INPUT = ospath.join(ospath.dirname(OUTPUT), 'proxy.ini')
        else:
            if '__loader__' in globals() and __loader__:
                DIR = ospath.dirname(__loader__.archive)
            else:
                DIR = ospath.dirname(__file__)
            INPUT = ospath.join(DIR, 'proxy.ini')
            OUTPUT = ospath.join(DIR, 'config.py')
    config = Common(INPUT).__dict__
    # from pprint import pprint
    # pprint(config)
    config['MTIME'] = int(os.stat(INPUT).st_mtime)
    code = SimpleTemplate(template).render(**config)
    # print code
    with open(OUTPUT, 'wb') as fp:
        fp.write(tob(code))

if __name__ == '__main__':
    make_config()
